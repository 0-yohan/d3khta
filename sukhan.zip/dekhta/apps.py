from django.apps import AppConfig


class DekhtaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dekhta'

    def ready(self):
        import dekhta.signals